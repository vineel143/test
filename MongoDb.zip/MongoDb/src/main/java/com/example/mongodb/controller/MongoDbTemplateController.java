package com.example.mongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongodb.model.Employee;
import com.example.mongodb.service.EmployeeServiceMongoTemplate;

@RestController
public class MongoDbTemplateController {

	@Autowired
	EmployeeServiceMongoTemplate employeeServiceMongoTemplate;

	@RequestMapping(method = RequestMethod.GET, value = "/template/getAccountById/{id}")
	public ResponseEntity<Employee> getAccountById(@PathVariable("id") String id) {

		Employee e = employeeServiceMongoTemplate.findById(id);
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<Employee>(e, status);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/template/getAccountById/{id}/{name}")
	public ResponseEntity<List<Employee>> getAccountByIdAndName(@PathVariable("id") String id, @PathVariable("name") String name) {

		List<Employee> e = employeeServiceMongoTemplate.findByIdAndName(id, name);
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<List<Employee>>(e, status);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/template/getAll") 
	public ResponseEntity<List<Employee>> getAll() {
		List<Employee> e = employeeServiceMongoTemplate.findAll();
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<List<Employee>>(e, status);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/template/save")

	public ResponseEntity<String> save(@RequestBody Employee account) {
		Employee response = employeeServiceMongoTemplate.save(account);
		if (null != response) {
			return new ResponseEntity<String>("Data Saved successFully", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Failed to Save Data", HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/template/delete/{id}")
	public ResponseEntity<Long> deleteById(@PathVariable("id") String id) {
		long e = employeeServiceMongoTemplate.deleteById(id);
		HttpStatus status = e != 0 ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<Long>(e, status);
	}

}