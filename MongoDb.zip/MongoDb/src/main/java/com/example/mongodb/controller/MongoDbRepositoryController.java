package com.example.mongodb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.mongodb.model.Employee;
import com.example.mongodb.service.EmployeeServiceRepository;

@RestController
public class MongoDbRepositoryController {

	@Autowired
	EmployeeServiceRepository employeeServiceRepository;

	@RequestMapping(method = RequestMethod.GET, value = "/getById/{id}")
	public ResponseEntity<Employee> getAccountById(@PathVariable("id") String id) {

		Employee e = employeeServiceRepository.findById(id);
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<Employee>(e, status);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/getById/{id}/{name}")
	public ResponseEntity<List<Employee>> getAccountByIdAndName(@PathVariable("id") String id, @PathVariable("name") String name) {

		List<Employee> e = employeeServiceRepository.findByIdAndName(id, name);
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<List<Employee>>(e, status);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/getAll") 
	public ResponseEntity<List<Employee>> getAll() {
		List<Employee> e = employeeServiceRepository.findAll();
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<List<Employee>>(e, status);
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/getAllAsync") 
	public ResponseEntity<List<Employee>> getAllAsync(@RequestParam("id") String id, @RequestParam("name") String name) {
		List<Employee> e = employeeServiceRepository.mergeAllDetails(id, name);
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<List<Employee>>(e, status);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/save")
	public ResponseEntity<String> save(@RequestBody Employee account) {
		Employee response = employeeServiceRepository.save(account);
		if (null != response) {
			return new ResponseEntity<String>("Data Saved successFully", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Failed to Save Data", HttpStatus.NOT_FOUND);
		}
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/delete/{id}")
	public ResponseEntity<Employee> deleteById(@PathVariable("id") String id) {

		Employee e = employeeServiceRepository.deleteById(id);
		HttpStatus status = e != null ? HttpStatus.OK : HttpStatus.NOT_FOUND;
		return new ResponseEntity<Employee>(e, status);
	}

}