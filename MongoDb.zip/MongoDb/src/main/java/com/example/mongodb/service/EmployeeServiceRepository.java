package com.example.mongodb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mongodb.model.Employee;
import com.example.mongodb.repository.EmployeeRepository;

@Service
public class EmployeeServiceRepository {
    
    @Autowired
    EmployeeRepository employeeRepository;
    
    @Autowired
    AsyncEmployeeService asyncEmployeeService;

    public Employee save(Employee employee) {
    	Employee res = employeeRepository.save(employee);
        return res;
    }
    
    public Employee findById(String id) {
    	Employee res = employeeRepository.findByEmpid(id);
        return res;
    }
    
    public List<Employee> findByIdAndName(String id, String name) {
    	List<Employee> res = employeeRepository.findByEmpidAndEmpname(id,name);
        return res;
    }
 
    public List<Employee> findAll() {
    	List<Employee> res = employeeRepository.findAll();
     	return res;
    }
    
    public Employee deleteById(String id) {
    	Employee res = employeeRepository.deleteByEmpid(id);
     	return res;
    }
    
    
    public List<Employee> mergeAllDetails(String id, String name){
    	List<Employee> finals = new ArrayList<>();

    	try {
    		CompletableFuture<List<Employee>> res = asyncEmployeeService.findById(id);
        	CompletableFuture<List<Employee>> res2 = asyncEmployeeService.findByIdAndName(id, name);
        	CompletableFuture.allOf(res, res2);
        	
			finals.addAll(res.get());
	    	finals.addAll(res2.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     	return finals;
    }
    
    
}