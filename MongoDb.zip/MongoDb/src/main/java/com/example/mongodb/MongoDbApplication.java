package com.example.mongodb;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.example.mongodb.repository.EmployeeRepository;

@SpringBootApplication
@ComponentScan("com.example")
@EnableMongoRepositories(basePackages = {"com.example.*"})	
public class MongoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbApplication.class, args);
	}

	
	@Bean
    CommandLineRunner init(EmployeeRepository domainRepository) {
        return args -> {
        };
    }
}
