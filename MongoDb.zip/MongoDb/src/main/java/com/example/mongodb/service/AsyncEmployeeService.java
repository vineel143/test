package com.example.mongodb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.example.mongodb.model.Employee;
import com.example.mongodb.repository.EmployeeRepository;

@Service
public class AsyncEmployeeService {
    
    @Autowired
    EmployeeRepository employeeRepository;

    @Async("asyncex")
    public CompletableFuture<List<Employee>> findById(String id) throws InterruptedException {
    	List<Employee> res1 = new ArrayList<>();
    	Employee res = employeeRepository.findByEmpid(id);
    	res1.add(res);
    	Thread.sleep(1000L);
        return CompletableFuture.completedFuture(res1);
    }
    
    @Async("asyncex")
    public CompletableFuture<List<Employee>> findByIdAndName(String id, String name) throws InterruptedException {
    	List<Employee> res = employeeRepository.findByEmpidAndEmpname(id,name);
    	Thread.sleep(1000L);
        return CompletableFuture.completedFuture(res);
    }
    
}