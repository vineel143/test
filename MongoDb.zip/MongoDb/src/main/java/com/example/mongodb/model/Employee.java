package com.example.mongodb.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document
public class Employee {
 
    @Id
    private String empid;
    
    @JsonProperty("empname")
	private String empname;
    
    @JsonProperty("empage")
    private String empage;
    
    
    public String getEmpid() {
		return empid;
	}
	public void setEmpid(String empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmpage() {
		return empage;
	}
	public void setEmpage(String empage) {
		this.empage = empage;
	}

}