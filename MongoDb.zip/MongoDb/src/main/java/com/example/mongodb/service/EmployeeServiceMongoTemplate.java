package com.example.mongodb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.example.mongodb.model.Employee;
import com.mongodb.client.result.DeleteResult;

@Service
public class EmployeeServiceMongoTemplate {
    
    
    @Autowired
    MongoTemplate mongoTemplate;

    public Employee save(Employee employee) {
    	Employee res = mongoTemplate.save(employee);
        return res;
    }
      
    public Employee findById(String id) {
    	Query query = new Query(Criteria.where("_id").is(id));
    	Employee res = mongoTemplate.findOne(query,  Employee.class);
        return res;
    }
    
    public List<Employee> findByIdAndName(String id, String name) {
    	Query query = new Query(Criteria.where("_id").is(id).where("empname").is(name));
    	List<Employee> res = mongoTemplate.find(query, Employee.class);
    	return res;
    }
 
    public List<Employee> findAll() {
    	List<Employee> res = mongoTemplate.findAll(Employee.class);
     	return res;
    }
    
    public long deleteById(String id) {
    	Query query = new Query(Criteria.where("_id").is(id));
    	DeleteResult res = mongoTemplate.remove(query, Employee.class);
     	return res.getDeletedCount();
    }
   
    
}