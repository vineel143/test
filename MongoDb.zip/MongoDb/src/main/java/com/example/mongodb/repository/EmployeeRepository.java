package com.example.mongodb.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.DeleteQuery;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.mongodb.model.Employee;


public interface EmployeeRepository extends MongoRepository<Employee, Object>{
	
	Employee findByEmpid(String empid);
	
	List<Employee> findByEmpidAndEmpname(String id, String name);
	
	@DeleteQuery
	Employee deleteByEmpid(String empid);

	
	/*
	 * Flux<Employee> findEmployeeById(String id); Flux<Employee>
	 * findEmployeeByIdAndName(String id, String name); Flux<Employee>
	 * findEmployee(String id); Mono<Employee> findEmployee_(String id);
	 * List<Employee> findAll(); Mono<Employee> UpdateEmployee(String id, String
	 * Name, String age);
	 */
}